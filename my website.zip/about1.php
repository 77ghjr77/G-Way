<?php require('incsession.php'); ?>
<!DOCTYPE html>
<html lang="">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>賴志偉的手機網站</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->

<body class="main-layout ">
    <!-- loader  -->
    <div class="loader_bg">
        <div class="loader"><img src="images/loading.gif" alt="#" /></div>
    </div>
    <!-- end loader -->
    <!-- header -->
    <header>
        <!-- header inner -->
        <div class="header">

            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                        <div class="full">
                            <div class="center-desk">
                                <div class="logo">
                                    <a href="index.html"><img src="images/logo.png" alt="#"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                        <div class="menu-area">
                            <div class="limit-box">
                                <nav class="main-menu">
                                    <ul class="menu-area-main">
                                        <li class="active"> <a href="index1.php">首頁</a> </li>
                                        <li> <a href="about1.php">關於我們</a> </li>
                                        <li><a href="brand1.php">目錄</a></li>
                                        <li><a href="shop.php">購買</a></li>
                                        <li><a class="logout1" href="logout.php">登出</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
        <!-- end header inner -->
    </header>
    <!-- end header -->

    <div class="brand_color">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="titlepage">
                        <h2>關於我們</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- about -->
    <div class="about">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-5 col-md-5 co-sm-l2">
                    <div class="about_img">
                        <figure><img src="images/about.png" alt="img" /></figure>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7 col-md-7 co-sm-l2">
                    <div class="about_box">
                        <span>智慧型手機</span>
                        <p>智慧型手機（英語：Smartphone）它是一種可用來撥打行動電話和進行多功能行動計算的裝置。有客製化的行動操作系統，可瀏覽網頁和播放多媒體檔案，也可通過安裝應用軟體、電子遊戲等程式來擴充功能。智慧型手機通常有許多半導體以及各種感測器，支援無線通訊協定。其運算能力及功能均優於傳統功能型手機。

最初的智慧型手機功能並不多，主要是面向商務市場，試圖消除支援電話功能的PDA與傳統手機的區別，後來的機型增加了可攜式媒體播放器、數位相機和閃光燈（手電筒）、和GPS導航、NFC、重力感應水平儀等功能，使其成為了一種功能多樣化的裝置，透過這樣的破壞性創新，智慧型手機徹底成為了電子市場主流硬體，淘汰了相當多在20世紀末所推出的各類電子產品。

到了21世紀初，市場上的智慧型手機主要搭載黑莓、塞班、Windows Mobile系統。這時手機擁有高解析度、觸控螢幕和網頁瀏覽器，從而可以顯示標準網頁以及行動網頁，透過Wi-Fi和行動寬頻，也還能實現次世代高速資料存取。通常使用全鍵盤而非觸控螢幕輸入的設計，主打郵件推播和無線網路；而從2007年第一代iPhone面世，主流手機逐漸變成了正面為平面的設計，大尺寸的多點觸控螢幕取代了原來的實體鍵盤，而且開始提供使用者下載與購買軟體程式的軟體商店，也開始具有雲端儲存和同步、虛擬助理，乃至行動支付的服務。

今日，隨著行動網際網路的發展，智慧型手機成為核心的通訊工具，行動應用程式市場及行動商務、手機遊戲產業、社交即時通訊網路高度繁榮，甚至產生了相關的職業。通訊技術的發展，萬物互聯概念的提出，使得智慧型手機成為了重要的終端裝置，進駐了現代社會的各方面，已經是不可取代的物品。 ---以上來自維基百科</p>

                    </div>
                </div>
                <div class="col-xl-7 col-lg-7 col-md-7 co-sm-l2">
                    <div class="about_box_ ">
                        <span>手機系統軟體</span>
                        <p>「智慧型手機」這個說法主要是針對「功能型手機」而來的，對於那些運算能力及功能比傳統功能手機更強的手機的集合性稱謂。

業內人士認為，智慧型手機能夠顯示與個人電腦所顯示出來一致的正常網頁，而且智慧型手機能顯示手機版的網頁，它具有行動作業系統以及良好的使用者介面，它擁有很強的應用擴展性、能方便隨意地安裝和刪除應用程式；智慧型手機擁有超大高畫質觸控螢幕，能隨時使用鍵盤來進行觸摸、手寫、進行多任務操作，並且擁有強大的多媒體、郵件、上網功能，能完全替代像MP3、MP4和PDA這樣的傳統攜帶式裝置；智慧型手機能替代個人電腦處理辦公事務和其他事務，它能隨時與網路保持連接，並且能與電腦、筆記型電腦等其他裝置同步資料。

智慧型手機的新定義使得智慧型手機與傳統功能型手機能完全區分開來，不再是之前的模糊關係。同樣，早期的蘋果iOS系統與微軟Windows Phone系統不支援智慧型手機應有的多任務處理，是否為智慧型手機系統有許多爭議。但隨後蘋果發布的iOS 4支援多任務處理；而微軟也發布的Windows Phone 7.5支援多任務處理，至此兩者都能認定為智慧型手機系統。

智慧型手機有別於普通帶有觸控式螢幕的手機。一般普通帶有觸控式螢幕的手機使用的都是生產廠商自行開發的封閉式作業系統，再透過JAVA平台來增加其他應用，所能實現的功能非常有限。 ---以上來自維基百科</p>

                    </div>
                </div>
                <div class="col-xl-5 col-lg-5 col-md-5 co-sm-l2">
                    <div class="about_img">
                        <figure><img src="images/about1.png" alt="img" /></figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- end about -->

    <!-- footer -->
    <footer>
        <div id="contact" class="footer">
            <div class="container">
                <div class="row pdn-top-30">
                    <div class="col-md-12 ">
                        <div class="footer-box">
                            <div class="headinga">
                                <h3>地址</h3>
                                <span>桃源市新樁區大德路87號</span>
                                <p>(+71) 123456789
                                    <br>demo@gmail123456.com</p>
                            </div>
                            <ul class="location_icon">
                                <li> <a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li> <a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li> <a href="#"><i class="fa fa-instagram"></i></a></li>

                            </ul>
                            <div class="menu-bottom">
                                <ul class="link">
                                    <li> <a href="index1.php">首頁</a> </li>
                                    <li> <a href="about1.php">關於我們</a> </li>
                                    <li><a href="brand1.php">目錄</a></li>
                                    <li><a href="shop.php">購買</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright">
                <div class="container">
                    <p>© 2021 All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </footer>
    <!-- end footer -->
    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-3.0.0.min.js"></script>
    <script src="js/plugin.js"></script>
    <!-- sidebar -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/custom.js"></script>
    <!-- javascript -->
    <script src="js/owl.carousel.js"></script>
    <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".fancybox").fancybox({
                openEffect: "none",
                closeEffect: "none"
            });

            $(".zoom").hover(function() {

                $(this).addClass('transition');
            }, function() {

                $(this).removeClass('transition');
            });
        });
    </script>
</body>

</html>