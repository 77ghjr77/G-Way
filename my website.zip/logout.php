<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
//將session清空
unset($_COOKIE['session_id']);
unset($cookieexpiry);
unset($_SESSION['username']);
session_destroy();//清空購物車
setcookie('username', '', time()-99);
setcookie('session_id', '', time()-99);
echo '登出中......';
echo '<meta http-equiv=REFRESH CONTENT=1;url=index.html>';
?>