<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<?php
  $DB_HOST        = "sql206.epizy.com";  //資料庫主機
  $DB_LOGIN       = "epiz_27911835";       //登入資料庫主機使用帳號
  $DB_PASSWORD    = "dVHOWplF6q";       //登入資料庫主機使用密碼
  $DB_NAME        = "epiz_27911835_123";     //目前使用的資料庫名稱

//對資料庫連線
if(!@mysql_connect($DB_HOST, $DB_LOGIN, $DB_PASSWORD))
        die("無法對資料庫連線");

//資料庫連線採UTF8
mysql_query("SET NAMES utf8");

//選擇資料庫
if(!@mysql_select_db($DB_NAME))
        die("無法使用資料庫");
?>


