<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
include("mysql_connect.inc.php");

$id = $_POST['id'];
$pw = $_POST['pw'];
$pw2 = $_POST['pw2'];
$name = $_POST['name'];
$sex = $_POST['sex'];
$telephone = $_POST['telephone'];
$other = $_POST['other'];

$sql = "SELECT * FROM member where username = '$id'";
$result = mysql_query($sql);
$row = @mysql_fetch_row($result);
if($row[0] == $id)
{
    echo '帳號已有人使用,請換一個!';
    echo '<meta http-equiv=REFRESH CONTENT=2;url=register.php>';

}
else
{

//判斷帳號密碼是否為空值
//確認密碼輸入的正確性
if($id != null && $pw != null && $pw2 != null && $pw == $pw2)
{
        //新增資料進資料庫語法
        $sql = "insert into member (username, password, name, sex, telephone, other) values ('$id', '$pw', '$name', '$sex', '$telephone', '$other')";
        if(mysql_query($sql))
        {
                echo '新增成功!';
                echo '<meta http-equiv=REFRESH CONTENT=2;url=login.html>';
        }
        else
        {
                echo '新增失敗!';
                echo '<meta http-equiv=REFRESH CONTENT=2;url=register.php>';
        }
}
else
{
        echo '新增失敗!';
        echo '<meta http-equiv=REFRESH CONTENT=2;url=register.php>';
}
}
?>