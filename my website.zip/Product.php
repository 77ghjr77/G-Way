<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>購物車加入範例</title>
<script type="text/javascript" src="js/menu.js"></script>
<link rel="shortcut icon" href="images/i.ico" />
</head>
<body>
<div class="right_main">

<div class="product clearfix">
<div class="product_body fle">
<div class="product_poto fle"></div>
<div class="product_word fle">
<div class="product_word_tit">測試資料</div>
<div class="product_word_word">規 格：122<br />
<span class="product_word_word_w1">定 價：0 元</span><br />

<span class="product_word_word_w2">售 價：200 元<br />
</span></div>
<div class="product_word_shopping"><input class="product_bt"
	style="cursor: pointer;" onclick="location='addItem.php?sn=1';"
	value="加入購物車" type="button" /></div>
</div>
</div>

<div class="product_body fle">

<div class="product_poto fle"></div>
<div class="product_word fle">
<div class="product_word_tit">test</div>
<div class="product_word_word">規 格：122<br />
<span class="product_word_word_w1">定 價：1 元</span><br />
<span class="product_word_word_w2">售 價：1 元<br />

紅利金：10 元 </span></div>
<div class="product_word_shopping"><input class="product_bt"
	style="cursor: pointer;" onclick="location='addItem.php?sn=3';"
	value="加入購物車" type="button" /></div>
</div>
</div>

<div class="product_body fle">
<div class="product_poto fle"></div>

<div class="product_word fle">
<div class="product_word_tit">測試資料2</div>
<div class="product_word_word"><br />
<span class="product_word_word_w1">定 價：0 元</span><br />
<span class="product_word_word_w2">售 價：0 元<br />
</span></div>
<div class="product_word_shopping"><input class="product_bt"
	style="cursor: pointer;" onclick="location='addItem.php?sn=2';"
	value="加入購物車" type="button" /></div>
</div>
</div>

</div>
</div>
</body>
</html>
