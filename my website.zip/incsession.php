<?php
require('mysql_connect.inc.php');

// Check for a cookie, if none go to login page
if (!isset($_COOKIE['session_id']))
{
    header('Location: login.html?refer='. urlencode(getenv('REQUEST_URI')));
}

// Try to find a match in the database
$guid = $_COOKIE['session_id'];
$con = mysql_connect($DB_HOST, $DB_LOGIN, $DB_PASSWORD);
mysql_select_db($DB_NAME, $con);

$query = "SELECT username FROM member WHERE password = '$guid'";
$result = mysql_query($query, $con);

if (!mysql_num_rows($result))
{
    // No match for guid
header('Location: login.html?refer='. urlencode(getenv('REQUEST_URI')));
}
?>